/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author huawei
 */
public class InputValidator {
    public static boolean validateEmail(String email) {
        return email.matches("^[\\w-\\.]+@[\\w-]+\\.[a-z]{2,4}$");
    }

    public static boolean validatePassword(String password) {
        return password.length() >= 6;
    }
}
