/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author huawei
 */
import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Lecturer {

    private static final String LECTURER_FILE = "lecturers.txt";

    // Method to get Lecturer's Name by ID
    public static String getNameById(String lecturerId) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(LECTURER_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",", -1);
                if (parts[0].equals(lecturerId)) {
                    return parts[1]; // Lecturer's name
                }
            }
        }
        return "Unknown Lecturer";
    }

    // Method to Remove a Slot
    public static void removeSlot(String lecturerId, String timeSlot) throws IOException {
        File tempFile = new File("lecturers_temp.txt");
        File originalFile = new File(LECTURER_FILE);

        try (
                BufferedReader reader = new BufferedReader(new FileReader(originalFile)); BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",", -1);
                if (parts[0].equals(lecturerId)) {
                    if (parts.length > 4 && !parts[4].isEmpty()) {
                        String[] slots = parts[4].split(";");
                        StringBuilder updatedSlots = new StringBuilder();
                        for (String slot : slots) {
                            if (!slot.trim().equals(timeSlot)) {
                                updatedSlots.append(slot).append(";");
                            }
                        }
                        parts[4] = updatedSlots.toString();
                    }
                    line = String.join(",", parts);
                }
                writer.write(line);
                writer.newLine();
            }
        }

        if (!originalFile.delete() || !tempFile.renameTo(originalFile)) {
            throw new IOException("Error updating lecturer slots.");
        }
    }

    // View Available Slots
    public static void viewAvailableSlots(String lecturerId) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(LECTURER_FILE))) {
            String line;
            boolean found = false;

            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",", -1);
                if (parts[0].equals(lecturerId)) {
                    found = true;
                    System.out.println("\n=== Available Slots ===");
                    if (parts.length > 4 && !parts[4].isEmpty()) {
                        String[] slots = parts[4].split(";");
                        for (String slot : slots) {
                            System.out.println(" - " + slot);
                        }
                    } else {
                        System.out.println("No available slots.");
                    }
                    break;
                }
            }

            if (!found) {
                System.out.println("Lecturer not found.");
            }
        }
    }

    // Add a Consultation Slot
    public static void addSlot(String lecturerId, String timeSlot) throws IOException {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime slotTime;

        // Validate time slot format and ensure it's not in the past
        try {
            slotTime = LocalDateTime.parse(timeSlot, formatter);
            if (slotTime.isBefore(now)) {
                System.out.println("Cannot add a past slot. Please enter a future time.");
                return;
            }
        } catch (Exception e) {
            System.out.println("Invalid date-time format. Please use 'yyyy-MM-dd HH:mm'.");
            return;
        }

        File tempFile = new File("lecturers_temp.txt");
        File originalFile = new File(LECTURER_FILE);

        boolean slotAdded = false;
        boolean slotExists = false;

        try (
                BufferedReader reader = new BufferedReader(new FileReader(originalFile)); BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",", -1);
                if (parts[0].equals(lecturerId)) {
                    if (parts.length > 4 && !parts[4].isEmpty()) {
                        String[] slots = parts[4].split(";");
                        for (String slot : slots) {
                            if (slot.trim().equals(timeSlot)) {
                                slotExists = true;
                                break;
                            }
                        }
                        if (!slotExists) {
                            parts[4] += timeSlot + ";";
                            slotAdded = true;
                        }
                    } else {
                        parts = expandArray(parts, 5);
                        parts[4] = timeSlot + ";";
                        slotAdded = true;
                    }
                    line = String.join(",", parts);
                }
                writer.write(line);
                writer.newLine();
            }
        }

        if (!originalFile.delete()) {
            System.out.println("Error deleting original file.");
            return;
        }
        if (!tempFile.renameTo(originalFile)) {
            System.out.println("Error renaming temp file.");
            return;
        }

        if (slotExists) {
            System.out.println("This slot already exists. Duplicate slots are not allowed.");
        } else if (slotAdded) {
            System.out.println("Slot added successfully!");
        }
    }
public static void deleteSlot(String lecturerId, String timeSlot) throws IOException {
    File tempFile = new File("lecturers_temp.txt");
    File originalFile = new File(LECTURER_FILE);

    boolean slotDeleted = false;

    try (BufferedReader reader = new BufferedReader(new FileReader(originalFile));
         BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {
        String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(",", -1);
            if (parts[0].equals(lecturerId)) {
                if (parts.length > 4 && !parts[4].isEmpty()) {
                    String[] slots = parts[4].split(";");
                    StringBuilder updatedSlots = new StringBuilder();

                    for (String slot : slots) {
                        if (!slot.trim().equals(timeSlot)) {
                            updatedSlots.append(slot).append(";");
                        } else {
                            slotDeleted = true;
                        }
                    }

                    parts[4] = updatedSlots.toString(); // Update slots
                    line = String.join(",", parts);
                }
            }
            writer.write(line);
            writer.newLine();
        }
    }

    // Replace the original file with the updated file
    if (!originalFile.delete() || !tempFile.renameTo(originalFile)) {
        System.out.println("Error updating lecturer file.");
    }

    // Feedback to the lecturer
    if (slotDeleted) {
        System.out.println("Slot deleted successfully!");
    } else {
        System.out.println("Slot not found. No changes were made.");
    }
}

    public static String[] getAvailableSlots(String lecturerId) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(LECTURER_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",", -1);
                if (parts[0].equals(lecturerId) && parts.length > 4 && !parts[4].isEmpty()) {
                    return parts[4].split(";");
                }
            }
        }
        return new String[0];
    }

    // Utility to expand an array for additional fields
    private static String[] expandArray(String[] original, int newSize) {
        String[] expanded = new String[newSize];
        System.arraycopy(original, 0, expanded, 0, original.length);
        return expanded;
    }

    public static boolean isSlotAvailable(String lecturerId, String timeSlot) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(LECTURER_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",", -1);
                if (parts[0].equals(lecturerId) && parts.length > 4 && !parts[4].isEmpty()) {
                    String[] slots = parts[4].split(";");
                    for (String slot : slots) {
                        if (slot.trim().equals(timeSlot)) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    // Get Lecturer ID by Email
    public static String getLecturerIdByEmail(String email) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(LECTURER_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[2].equals(email)) { // Email matches
                    return parts[0]; // Return the ID
                }
            }
        }
        return null; // Return null if not found
    }

    // Authenticate a Lecturer
    public static boolean authenticate(String email, String password) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(LECTURER_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[2].equals(email) && parts[3].equals(password)) {
                    return true;
                }
            }
        }
        return false;
    }
}
