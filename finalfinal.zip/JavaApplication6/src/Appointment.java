/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author huawei
 */
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Appointment {
    private Student student;
    private Lecturer lecturer;
    private LocalDateTime timeSlot;
    private String status;

    public Appointment(Student student, Lecturer lecturer, String timeSlot, String status) {
        this.student = student;
        this.lecturer = lecturer;
        this.timeSlot = LocalDateTime.parse(timeSlot, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
        this.status = status;
    }

    // Getter for the Student object
    public Student getStudent() {
        return student;
    }

    // Getter for the Lecturer object
    public Lecturer getLecturer() {
        return lecturer;
    }

    // Getter for the Time Slot
    public LocalDateTime getTimeSlot() {
        return timeSlot;
    }

    // Getter for the Status
    public String getStatus() {
        return status;
    }

    @Override
    public String toString() {
        return "Date and Time: " + timeSlot.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")) +
               " | Status: " + status;
    }
}
