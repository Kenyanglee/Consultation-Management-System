/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author huawei
 */

import java.io.*;

public class Student {
    private static final String STUDENT_FILE = "students.txt";

    // Get Student ID by Email
    public static String getStudentIdByEmail(String email) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(STUDENT_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[2].equals(email)) { // Email matches
                    return parts[0]; // Return the ID
                }
            }
        }
        return null; // Return null if not found
    }

    // Get Student Name by ID
    public static String getNameById(String studentId) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(STUDENT_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[0].equals(studentId)) {
                    return parts[1]; // Student Name
                }
            }
        }
        return "Unknown Student";
    }

    // Authenticate a student
    public static boolean authenticate(String email, String password) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(STUDENT_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[2].equals(email) && parts[3].equals(password)) {
                    return true;
                }
            }
        }
        return false;
    }

    // Register a new student
    public static void registerStudent(String id, String name, String email, String password) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(STUDENT_FILE, true))) {
            writer.write(id + "," + name + "," + email + "," + password);
            writer.newLine();
        }
    }
}
